#pragma once

#include "CGFObject.h"

class MyUnitCube: public CGFobject {
public:
	void draw();
	void rectangle(float,float,float,float);
};

