#pragma once

#include "CGFObject.h"
#include "MyUnitCube.h"

class MyFloor: public CGFobject {
public:
	void draw();
};

