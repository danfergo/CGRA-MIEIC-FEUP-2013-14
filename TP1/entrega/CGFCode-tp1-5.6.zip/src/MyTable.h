#pragma once

#include "CGFObject.h"
#include "MyUnitCube.h"

class MyTable: public CGFobject {
public:
	void draw();
};

