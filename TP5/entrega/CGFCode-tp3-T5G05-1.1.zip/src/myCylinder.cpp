#include "myCylinder.h"

myCylinder::myCylinder(int slices, int stacks/*, bool smooth*/) {
	
}
