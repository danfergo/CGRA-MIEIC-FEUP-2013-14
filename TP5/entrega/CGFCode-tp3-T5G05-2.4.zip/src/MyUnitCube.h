#pragma once

#include "CGFObject.h"

class MyUnitCube: public CGFobject {
public:
	void draw();
};

